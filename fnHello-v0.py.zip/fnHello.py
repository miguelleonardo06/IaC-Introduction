def handler(event, context):
    print("Hello world")
    return "Hello world"